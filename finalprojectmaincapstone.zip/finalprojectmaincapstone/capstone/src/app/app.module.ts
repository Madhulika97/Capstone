import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule , routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { LOGINPAGEComponent } from './login-page/login-page.component';
import { REGISTERPAGEComponent } from './register-page/register-page.component';
import { PersonalDetailsComponent } from './login-page/personal-details/personal-details.component';
import { LoginsuccessfulComponent } from './login-page/loginsuccessful/loginsuccessful.component';


@NgModule({
  declarations: [
    AppComponent,
    routingComponents,     
    ContactUSComponent,  
    FDRATESComponent,
    LOGINPAGEComponent, 
    REGISTERPAGEComponent, PersonalDetailsComponent, LoginsuccessfulComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }



