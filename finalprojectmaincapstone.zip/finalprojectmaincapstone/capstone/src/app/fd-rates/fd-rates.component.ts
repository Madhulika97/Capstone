import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fd-rates',
  templateUrl: './fd-rates.component.html',
  styleUrls: ['./fd-rates.component.css']
})
export class FDRATESComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
