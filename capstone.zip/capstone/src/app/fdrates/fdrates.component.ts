import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fdrates',
  template: `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bootstrap 4 Striped Table</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <style type="text/css">
      .bs-example{
        margin: 20px;
      }
  </style>
  </head>
  <body>
  <div class="bs-example">
      <ul class="list-group">
        <li class="list-group-item list-group-item-info"><h5>Interest rates on Domestic, NRO & NRE deposits</h5></li>
        </ul>
      <table class="table table-striped">
          <thead>
              <tr>
                  <th>Tenure Period</th>
                  <th colspan="2">Rate of Interest (% p.a.) w.e.f June 17, 2019</th>
                  
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>7 days to 14 days</td>
                  <td>4.00</td>
                  <td>4.50</td>
                  
              </tr>
              <tr>
                  <td>15 days to 29 days</td>
                  <td>4.25</td>
                  <td>4.75</td>
                  
              </tr>
              <tr>
                  <td>30 days to 45 days</td>
                  <td>5.00</td>
                  <td>6.00</td>
                  
              </tr>            
              <tr>
                  <td>46 days to 60 days</td>
                  <td>6.00</td>
                  <td>6.50</td>
              
               </tr>
               <tr>
                  <td>61 days to 90 days</td>
                  <td>6.00</td>
                  <td>6.50</td>
              
              </tr>
               <tr>
                  <td>91 days to 120 days</td>
                  <td>6.00</td>
                  <td>6.50</td>
              
               </tr>            
               <tr>
                  <td>121 days to 184 days</td>
                  <td>6.00</td>
                  <td>6.50</td>
                  
              </tr>
              <tr>
                  <td>185 days to 289 days</td>
                  <td>6.50</td>
                  <td>7.00</td>
                  
              </tr>
              <tr>
                  <td>290 days to less than 1 year</td>
                  <td>6.75</td>
                  <td>7.25</td>
                  
              </tr>            
              <tr>
                  <td>1 year to 389 days</td>
                  <td>6.90</td>
                  <td>7.40</td>
                  
              </tr>
              <tr>
                  <td>390 days to 2 year</td>
                  <td>7.00</td>
                  <td>7.50</td>
                  
              </tr>
              <tr>
                  <td>2 years 1 day upto 3 years</td>
                  <td>7.30</td>
                  <td>7.80</td>
                  
              </tr>            
              <tr>
                  <td>3 years 1 day upto 5 years</td>
                  <td>7.25</td>
                  <td>7.75</td>
                  
              </tr>
              <tr>
                  <td>5 years 1 day upto 10 years</td>
                  <td>7.00</td>
                  <td>7.50</td>
                  
              </tr>
              <tr>
                  <td>5 years Tax saver FD(Max upto Rs. 1.50 lac)</td>
                  <td>7.25</td>
                  <td>7.75</td>
                  
              </tr>            
          </tbody>
      </table>
  </div>
  </body>
  </html>                                                       
  `,
  styles: []
})
export class FdratesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
