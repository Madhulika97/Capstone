import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule , routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { LOGINPAGEComponent } from './login-page/login-page.component';
import { REGISTERPAGEComponent } from './register-page/register-page.component';


@NgModule({
  declarations: [
    AppComponent,
    routingComponents,     
    ContactUSComponent,  
    FDRATESComponent,
    LOGINPAGEComponent, 
    REGISTERPAGEComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }



