import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FDRATESComponent } from './fd-rates.component';

describe('FDRATESComponent', () => {
  let component: FDRATESComponent;
  let fixture: ComponentFixture<FDRATESComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FDRATESComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FDRATESComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
